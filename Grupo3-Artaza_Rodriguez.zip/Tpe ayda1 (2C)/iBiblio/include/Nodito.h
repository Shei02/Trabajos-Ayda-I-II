#ifndef NODITO_H
#define NODITO_H


class Nodito
{
    public:
        Nodito();
        virtual ~Nodito();

    protected:

    private:
};

#endif // NODITO_H
