#include "Nodito.h"

Nodito::Nodito()
{
    //ctor
}

Nodito::~Nodito()
{
    //dtor
}
